<?php get_header() ; ?>
<!--START Section -->
<section> 
  
  <!--  //  map  -->
  <div class="container">
    <div class="col-md-12 text-center blogWrap2">
      <h3>WORK WE DID</h3>
      <span class="icon-title"> <span></span> <i class="fa fa-star"></i></span> </div>
      
      <div class="row gellaryWrap">
      <div class="col-md-3 col-sm-6 col-xs-12">
          <figure class="effect-kira"> 
            <figcaption>
              <p> <a href="#"><i class="fa fa-link effect-3a"></i></a> <a class="nivo-lightbox" href="images/portfolio/1.jpg" title="This is an image title" data-lightbox-gallery="gallery1"><i class="fa fa-search effect-3a"></i></a> </p>
            </figcaption>
          </figure>
          <div class="clearfix"></div>
          <div class="photo-title">
            <h5>Project Title</h5>
            <p>Project Description</p>
          </div>
          <!-- end .photo-title --> 
        </div><!--  // IMG Block  -->
        
        <div class="col-md-3 col-sm-6 col-xs-12">
          <figure class="effect-kira"> <img src="images/thumb1.jpg" alt="">
            <figcaption>
              <p> <a href="#"><i class="fa fa-link effect-3a"></i></a> <a class="nivo-lightbox" href="images/portfolio/1.jpg" title="This is an image title" data-lightbox-gallery="gallery1"><i class="fa fa-search effect-3a"></i></a> </p>
            </figcaption>
          </figure>
          <div class="clearfix"></div>
          <div class="photo-title">
            <h5>Project Title</h5>
            <p>Project Description</p>
          </div>
          <!-- end .photo-title --> 
        </div><!--  // IMG Block  -->
        
        <div class="col-md-3 col-sm-6 col-xs-12">
          <figure class="effect-kira"> <img src="images/thumb1.jpg" alt="">
            <figcaption>
              <p> <a href="#"><i class="fa fa-link effect-3a"></i></a> <a class="nivo-lightbox" href="images/portfolio/1.jpg" title="This is an image title" data-lightbox-gallery="gallery1"><i class="fa fa-search effect-3a"></i></a> </p>
            </figcaption>
          </figure>
          <div class="clearfix"></div>
          <div class="photo-title">
            <h5>Project Title</h5>
            <p>Project Description</p>
          </div>
          <!-- end .photo-title --> 
        </div><!--  // IMG Block  -->
        
        <div class="col-md-3 col-sm-6 col-xs-12">
          <figure class="effect-kira"> <img src="images/thumb1.jpg" alt="">
            <figcaption>
              <p> <a href="#"><i class="fa fa-link effect-3a"></i></a> <a class="nivo-lightbox" href="images/portfolio/1.jpg" title="This is an image title" data-lightbox-gallery="gallery1"><i class="fa fa-search effect-3a"></i></a> </p>
            </figcaption>
          </figure>
          <div class="clearfix"></div>
          <div class="photo-title">
            <h5>Project Title</h5>
            <p>Project Description</p>
          </div>
          <!-- end .photo-title --> 
        </div><!--  // IMG Block  -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <figure class="effect-kira"> <img src="images/thumb1.jpg" alt="">
            <figcaption>
              <p> <a href="#"><i class="fa fa-link effect-3a"></i></a> <a class="nivo-lightbox" href="images/portfolio/1.jpg" title="This is an image title" data-lightbox-gallery="gallery1"><i class="fa fa-search effect-3a"></i></a> </p>
            </figcaption>
          </figure>
          <div class="clearfix"></div>
          <div class="photo-title">
            <h5>Project Title</h5>
            <p>Project Description</p>
          </div>
          <!-- end .photo-title --> 
        </div><!--  // IMG Block  -->
      <div class="col-md-3 col-sm-6 col-xs-12">
          <figure class="effect-kira"> <img src="images/thumb1.jpg" alt="">
            <figcaption>
              <p> <a href="#"><i class="fa fa-link effect-3a"></i></a> <a class="nivo-lightbox" href="images/portfolio/1.jpg" title="This is an image title" data-lightbox-gallery="gallery1"><i class="fa fa-search effect-3a"></i></a> </p>
            </figcaption>
          </figure>
          <div class="clearfix"></div>
          <div class="photo-title">
            <h5>Project Title</h5>
            <p>Project Description</p>
          </div>
          <!-- end .photo-title --> 
        </div><!--  // IMG Block  -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <figure class="effect-kira"> <img src="images/thumb1.jpg" alt="">
            <figcaption>
              <p> <a href="#"><i class="fa fa-link effect-3a"></i></a> <a class="nivo-lightbox" href="images/portfolio/1.jpg" title="This is an image title" data-lightbox-gallery="gallery1"><i class="fa fa-search effect-3a"></i></a> </p>
            </figcaption>
          </figure>
          <div class="clearfix"></div>
          <div class="photo-title">
            <h5>Project Title</h5>
            <p>Project Description</p>
          </div>
          <!-- end .photo-title --> 
        </div><!--  // IMG Block  -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <figure class="effect-kira"> <img src="images/thumb1.jpg" alt="">
            <figcaption>
              <p> <a href="#"><i class="fa fa-link effect-3a"></i></a> <a class="nivo-lightbox" href="images/portfolio/1.jpg" title="This is an image title" data-lightbox-gallery="gallery1"><i class="fa fa-search effect-3a"></i></a> </p>
            </figcaption>
          </figure>
          <div class="clearfix"></div>
          <div class="photo-title">
            <h5>Project Title</h5>
            <p>Project Description</p>
          </div>
          <!-- end .photo-title --> 
        </div><!--  // IMG Block  -->
      </div>
      
  </div>
</section>
<!--END MidSection --> 
<?php  get_footer() ;?>