<?php
/**
 * awesome theme Theme Customizer.
 *
 * @package theme
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function theme_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';
}
add_action( 'customize_register', 'theme_customize_register' );

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function theme_customize_preview_js() {
	wp_enqueue_script( 'theme_customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), '20151215', true );
}
add_action( 'customize_preview_init', 'theme_customize_preview_js' );


Kirki::add_config( 'my_theme', array(
    'capability'    => 'edit_theme_options',
    'option_type'   => 'theme_mod',
) );

Kirki::add_panel( '1st_panel', array(
    'priority'    => 10,
    'title'       => __( 'HOME PAGE SETUP', 'textdomain' ),
    'description' => __( 'My Description', 'textdomain' ),
) );
Kirki::add_section( 'social_link', array(
	'title'      => esc_attr__( 'SOCIAL LINK', 'awesome-theme' ),
	 'panel'          => '1st_panel',
	'priority'   => 2,
	'capability' => 'edit_theme_options',
	'description' => esc_attr__( 'setup the social link for your website', 'awesome-theme' ),
) );
Kirki::add_section( 'footer_section', array(
	'title'      => esc_attr__( 'FOOTER SECTION', 'awesome-theme' ),
	'priority'   => 2,
	'capability' => 'edit_theme_options',
	'description' => esc_attr__( 'setup the FOOTER SECTION  for your website', 'awesome-theme' ),
) );
Kirki::add_field( 'footer_section', array(
	'type'     => 'textarea',
	'settings' => 'footer_section',
	'label'    => __( 'FOOTER SECTION ', 'awesome-theme' ),
	'description' => esc_attr__( 'setup the FOOTER SECTIONfor your website', 'awesome-theme' ),
	'help' => esc_attr__( 'setup the FOOTER SECTION for your website', 'awesome-theme' ),
	'section'  => 'footer_section',
	'default'  => esc_attr__( 'COPYRIGHT', 'awesome-theme' ),
	'priority' => 10,
) );
Kirki::add_field( 'facebook', array(
	'type'     => 'text',
	'settings' => 'facebook',
	'label'    => __( 'FACEBOOK URL ', 'awesome-theme' ),
	'description' => esc_attr__( 'setup the facebook link for your website', 'awesome-theme' ),
	'help' => esc_attr__( 'setup the facebook link for your website', 'awesome-theme' ),
	'section'  => 'social_link',
	'default'  => esc_attr__( 'https://facebook.com', 'awesome-theme' ),
	'priority' => 10,
) );
Kirki::add_field( 'twitter', array(
	'type'     => 'text',
	'settings' => 'twitter',
	'label'    => __( 'TWITTER_URL ', 'awesome-theme' ),
	'description' => esc_attr__( 'setup the twitter link for your website', 'awesome-theme' ),
	'help' => esc_attr__( 'setup the twitter link for your website', 'awesome-theme' ),
	'section'  => 'social_link',
	'default'  => esc_attr__( 'https://twitter.com', 'awesome-theme' ),

	'priority' => 10,
) );
Kirki::add_field( 'google', array(
	'type'     => 'text',
	'settings' => 'google',
	'label'    => __( 'G-PLUS_URL ', 'awesome-theme' ),
	'description' => esc_attr__( 'setup the twitter link for your website', 'awesome-theme' ),
	'help' => esc_attr__( 'setup the twitter link for your website', 'awesome-theme' ),
	'section'  => 'social_link',
	'default'  => esc_attr__( 'https://google.com', 'awesome-theme' ),
		'description' => esc_attr__( 'setup the google plus link for your website', 'awesome-theme' ),
	'priority' => 10,
) );
Kirki::add_field( 'contact_no', array(
	'type'     => 'text',
	'settings' => 'contact_no',
	'label'    => __( 'CONTACT NO', 'awesome-theme' ),
	'description' => esc_attr__( 'setup the CONTACT NO FOR your website', 'awesome-theme' ),
	'help' => esc_attr__( 'setup the CONTACT NO FOR your website', 'awesome-theme' ),
	'section'  => 'social_link',
	'default'  => esc_attr__( '1234567890', 'awesome-theme' ),
		'description' => esc_attr__( 'setup the google plus link for your website', 'awesome-theme' ),
	'priority' => 10,
) );
Kirki::add_section( 'slider', array(
	'title'      => esc_attr__( 'SLIDER', 'awesome-theme' ),
	 'panel'          => '1st_panel',
	'priority'   => 2,
	'capability' => 'edit_theme_options',
	'description' => esc_attr__( 'setup the social link for your website', 'awesome-theme' ),
) );

Kirki::add_field( 'my_config', array(
	'type'        => 'repeater',
	'label'       => esc_attr__( 'add slider', 'awesome-theme' ),
	'section'     => 'slider',
	'priority'    => 10,
	'settings'    => 'my_setting',
	'default'     => array(
		array(
			'link_text' => esc_attr__( 'Kirki Site', 'awesome-theme' ),
			'link_url'  => 'https://kirki.org',
		),
		array(
			'link_text' => esc_attr__( 'Kirki Repository', 'awesome-theme' ),
			'link_url'  => 'https://github.com/aristath/kirki',
		),
	),
	'fields' => array(
		'link_text' => array(
			'type'        => 'text',
			'label'       => esc_attr__( 'slider text', 'awesome-theme' ),
			'description' => esc_attr__( 'This will be the label for your link', 'awesome-theme' ),
			'default'     => '',
		),
		'link_sub_text' => array(
			'type'        => 'text',
			'label'       => esc_attr__( 'slider sub text', 'awesome-theme' ),
			'description' => esc_attr__( 'This will be the label for your link', 'awesome-theme' ),
			'default'     => '',
		),
		'button_text' => array(
			'type'        => 'text',
			'label'       => esc_attr__( 'call to action  text', 'awesome-theme' ),
			'description' => esc_attr__( 'This will be the label for your link', 'awesome-theme' ),
			'default'     => '',
		),
		'button_link' => array(
			'type'        => 'text',
			'label'       => esc_attr__( 'call to action  link', 'awesome-theme' ),
			'description' => esc_attr__( 'This will be the label for your link', 'awesome-theme' ),
			'default'     => '',
		),
		'link_url' => array(
	'type'        => 'image',
	'label'       => __( 'This is the label', 'awesome-theme' ),
	'description' => __( 'This is the control description', 'awesome-theme' ),
	'help'        => __( 'This is some extra help text.', 'awesome-theme' ),
	'default'     => '',
	
),
	)
) );
Kirki::add_section( 'welcome_note', array(
	'title'      => esc_attr__( 'WELCOME NOTE ', 'awesome-theme' ),
	 'panel'          => '1st_panel',
	'priority'   => 2,
	'capability' => 'edit_theme_options',
	'description' => esc_attr__( 'setup the social link for your website', 'awesome-theme' ),
) );
Kirki::add_field( 'title', array(
	'type'     => 'text',
	'settings' => 'title',
	'label'    => __( 'WELCOME NOTE TITLE ', 'awesome-theme' ),
	'description' => esc_attr__( 'setup the WELCOME NOTE TITLE ON HOME SCREEN for your website', 'awesome-theme' ),
	'help' => esc_attr__( 'setup the WELCOME NOTE TITLE ON HOME SCREEN for your website', 'awesome-theme' ),
	'section'  => 'welcome_note',
	'default'  => esc_attr__( 'WELCOME NOTE TITLE ON HOME SCREEN', 'awesome-theme' ),
		'description' => esc_attr__( 'setup the WELCOME NOTE TITLE for your website', 'awesome-theme' ),
	'priority' => 10,
) );
Kirki::add_field( 'discription', array(
	'type'     => 'textarea',
	'settings' => 'discription',
	'label'    => __( 'WELCOME NOTE DISCRIPTOIN ', 'awesome-theme' ),
	'description' => esc_attr__( 'setup the WELCOME NOTE DISCRIPTOIN for your website', 'awesome-theme' ),
	'help' => esc_attr__( 'setup the WELCOME NOTE DISCRIPTOIN for your website', 'awesome-theme' ),
	'section'  => 'welcome_note',
	'default'  => esc_attr__( 'WELCOME NOTE DISCRIPTOIN', 'awesome-theme' ),
		'description' => esc_attr__( 'setup the WELCOME NOTE DISCRIPTOIN for your website', 'awesome-theme' ),
	'priority' => 10,
) );
Kirki::add_field( 'wel_thumb', array(
	'type'        => 'image',
	'settings'    => 'wel_thumb',
	'label'       => __( 'WELCOME NOTE THUMBNAIL', 'awesome-theme' ),
	'description' => __( 'WELCOME NOTE THUMBNAIL SETUP', 'awesome-theme' ),
	'help'        => __( 'WELCOME NOTE THUMBNAIL SETUP.', 'awesome-theme' ),
	'section'     => 'welcome_note',
	'default'     => '',
	'priority'    => 10,
) );
Kirki::add_section( 'about_site', array(
	'title'      => esc_attr__( 'ABOUT SITE ', 'awesome-theme' ),
	 'panel'          => '1st_panel',
	'priority'   => 2,
	'capability' => 'edit_theme_options',
	'description' => esc_attr__( 'setup the social link for your website', 'awesome-theme' ),
) );
Kirki::add_field( 'about_site_sect', array(
	'type'        => 'repeater',
	'label'       => esc_attr__( 'ABOUT SITE SECTION ', 'awesome-theme' ),
	'section'     => 'about_site',
	'priority'    => 10,
	'settings'    => 'about_site_sect',
	'default'     => array(
		array(
			'about_title' => esc_attr__( 'Kirki Site', 'awesome-theme' ),
			'about_disc'  => 'https://kirki.org',
			'about_icon'  => 'https://kirki.org'
		),
		
	
	),
	'fields' => array(
		'about_title' => array(
			'type'        => 'text',
			'label'       => esc_attr__( 'ABOUT TITLE', 'awesome-theme' ),
			'description' => esc_attr__( 'This will be the ABOUT TITLE ', 'awesome-theme' ),
			'default'     => '',
		),
		'about_disc' => array(
			'type'        => 'textarea',
			'label'       => esc_attr__( 'DISCRIPTION', 'awesome-theme' ),
			'description' => esc_attr__( 'This will be DISCRIPTION', 'awesome-theme' ),
			'default'     => '',
		),
   'about_icon' => array(
	'type'        => 'image',
	'label'       => __( 'icon', 'awesome-theme' ),
	'description' => __( 'set icon', 'awesome-theme' ),
	'help'        => __( 'set icon', 'awesome-theme' ),
	'default'     => '',
	
),
)
) );

Kirki::add_section( 'testimonial', array(
	'title'      => esc_attr__( 'WHAT CLIENT SAY ', 'awesome-theme' ),
	 'panel'          => '1st_panel',
	'priority'   => 2,
	'capability' => 'edit_theme_options',
	'description' => esc_attr__( 'ADD  WHAT CLIENT SAY', 'awesome-theme' ),
) );
Kirki::add_field( 'testinomials', array(
	'type'        => 'repeater',
	'label'       => esc_attr__( 'TESTINOMIALS', 'awesome-theme' ),
	'section'     => 'testimonial',
	'priority'    => 10,
	'settings'    => 'tetinomial',
	'default'     => array(
		array(
			'link_text' => esc_attr__( '', 'awesome-theme' ),
			'link_url'  => 'https://kirki.org',
		),
		array(
			'link_text' => esc_attr__( 'Kirki Repository', 'awesome-theme' ),
			'link_url'  => 'https://github.com/aristath/kirki',
		),
	),
	'fields' => array(
			'client_say' => array(
			'type'        => 'textarea',
			'label'       => esc_attr__( 'CLIENT QUOTE', 'awesome-theme' ),
			'description' => esc_attr__( 'This will be CLIENT QUOTE', 'awesome-theme' ),
			'default'     => '',
		),
			'client_name' => array(
			'type'        => 'text',
			'label'       => esc_attr__( 'CLIENT NAME', 'awesome-theme' ),
			'description' => esc_attr__( 'This will be CLIENT NAME', 'awesome-theme' ),
			'default'     => '',
		),
			'client_prof' => array(
			'type'        => 'image',
			'label'       => __( 'client profile', 'awesome-theme' ),
			'description' => __( 'set client profile', 'awesome-theme' ),
			'help'        => __( 'set client profile', 'awesome-theme' ),
			'default'     => '',
	
   ),
	)
) );
Kirki::add_section( 'brand_logo', array(
	'title'      => esc_attr__( 'BRAND LOGO ', 'awesome-theme' ),
	 'panel'          => '1st_panel',
	'priority'   => 2,
	'capability' => 'edit_theme_options',
	'description' => esc_attr__( 'ADD  BRAND LOGO', 'awesome-theme' ),
) );
Kirki::add_field( 'barand_logo', array(
	'type'        => 'repeater',
	'label'       => esc_attr__( 'BRAND LOGO', 'awesome-theme' ),
	'section'     => 'brand_logo',
	'priority'    => 10,
	'settings'    => 'brand_logo',
	'default'     => array(
		array(
			'brand_logo' => esc_attr__( '', 'awesome-theme' ),
		),
		
	 ),
	'fields' =>array(
			'brand_logo' => array(
			'type'        => 'image',
			'label'       => __( 'BRAND LOGO', 'awesome-theme' ),
			'description' => __( 'set BRAND LOGO', 'awesome-theme' ),
			'help'        => __( 'set BRAND LOGO', 'awesome-theme' ),
			'default'     => '',
	
   ),
   )
	 
) );
Kirki::add_section( 'our_team', array(
	'title'      => esc_attr__( 'OUR TEAM', 'awesome-theme' ),
	 'panel'          => '1st_panel',
	'priority'   => 2,
	'capability' => 'edit_theme_options',
	'description' => esc_attr__( 'ADD  TEAM MEMBER', 'awesome-theme' ),
) );
Kirki::add_field( 'team_name', array(
	'type'        => 'text',
	'settings'    => 'team_name',
	'label'       => __( 'TEAM NAME', 'awesome-theme' ),
	'description' => __( 'SET TEAM NAME', 'awesome-theme' ),
	'help'        => __( 'SET TEAM NAME', 'awesome-theme' ),
	'section'     => 'our_team',
	'default'     => '',
	'priority'    => 10,
) );
Kirki::add_field( 'team_details', array(
	'type'        => 'textarea',
	'settings'    => 'team_details',
	'label'       => __( 'TEAM DETAILS', 'awesome-theme' ),
	'description' => __( 'SET TEAM DETAILS', 'awesome-theme' ),
	'help'        => __( 'WSET TEAM DETAILS', 'awesome-theme' ),
	'section'     => 'our_team',
	'default'     => '',
	'priority'    => 10,
) );
Kirki::add_field( 'founder', array(
	'type'        => 'text',
	'settings'    => 'founder',
	'label'       => __( 'FOUNDER AND SEO ', 'awesome-theme' ),
	'description' => __( 'SET FOUNDER AND SEO', 'awesome-theme' ),
	'help'        => __( 'WSET FOUNDER AND SEO', 'awesome-theme' ),
	'section'     => 'our_team',
	'default'     => '',
	'priority'    => 10,
) );
Kirki::add_field( 'team_member', array(
	'type'        => 'repeater',
	'label'       => esc_attr__( 'TEAM MEMBER', 'awesome-theme' ),
	'section'     => 'our_team',
	'priority'    => 10,
	'settings'    => 'team_member',
	'default'     => array(
		array(
			'team_member_thumb' => esc_attr__( '', 'awesome-theme' ),
			'team_member_name' => esc_attr__( '', 'awesome-theme' ),
			'team_member_desgi' => esc_attr__( '', 'awesome-theme' ),
		),
		
	 ),
	'fields' =>array(
			'team_member_thumb' => array(
			'type'        => 'image',
			'label'       => __( 'TEAM MEMBER THUMBNAIL', 'awesome-theme' ),
			'description' => __( 'set MEMBER THUMBNAIL', 'awesome-theme' ),
			'help'        => __( 'set MEMBER THUMBNAIL', 'awesome-theme' ),
			'default'     => '',
	
   ),
   'team_member_name' => array(
			'type'        => 'text',
			'label'       => __( 'TEAM MEMBER NAME', 'awesome-theme' ),
			'description' => __( 'set MEMBER NAME', 'awesome-theme' ),
			'help'        => __( 'set MEMBER NAME', 'awesome-theme' ),
			'default'     => '',
	
   ),
   'team_member_desig' => array(
			'type'        => 'text',
			'label'       => __( 'TEAM MEMBER DESIGNATION ', 'awesome-theme' ),
			'description' => __( 'set MEMBER DESIGNATION', 'awesome-theme' ),
			'help'        => __( 'set MEMBER DESIGNATION', 'awesome-theme' ),
			'default'     => '',
	
   ),
   
   )
	 
) );
Kirki::add_section( 'why_choose_us', array(
	'title'      => esc_attr__( 'WHY CHOOSE US', 'awesome-theme' ),
	 'panel'          => '1st_panel',
	'priority'   => 2,
	'capability' => 'edit_theme_options',
	'description' => esc_attr__( 'WHY CHOOSE US SECTION', 'awesome-theme' ),
) );
Kirki::add_field( 'why_choose_us_section', array(
	'type'        => 'repeater',
	'label'       => esc_attr__( 'TAB SECTION', 'awesome-theme' ),
	'section'     => 'why_choose_us',
	'priority'    => 10,
	'settings'    => 'why_choose_us_section',
	'default'     => array(
		array(
			'tab_title' => esc_attr__( '', 'awesome-theme' ),
			'tab_discription' => esc_attr__( '', 'awesome-theme' ),	
		),
		
	 ),
	'fields' =>array(
	
   'tab_title' => array(
			'type'        => 'text',
			'label'       => __( 'TAB TITLE', 'awesome-theme' ),
			'description' => __( 'set TAB TITLE', 'awesome-theme' ),
			'help'        => __( 'set TAB TITLE', 'awesome-theme' ),
			'default'     => '',
	
   ),
   'tab_discription' => array(
			'type'        => 'text',
			'label'       => __( ' TAB DISCRIPTION ', 'awesome-theme' ),
			'description' => __( 'set TAB DISCRIPTION', 'awesome-theme' ),
			'help'        => __( 'set TAB DISCRIPTION', 'awesome-theme' ),
			'default'     => '',
	
   ),
   
   )
	 
) );
Kirki::add_section( 'more_features', array(
	'title'      => esc_attr__( 'MORE FEATURES', 'awesome-theme' ),
	 'panel'          => '1st_panel',
	'priority'   => 2,
	'capability' => 'edit_theme_options',
	'description' => esc_attr__( 'MORE FEATURES SECTION', 'awesome-theme' ),
) );
Kirki::add_field( 'more_features_section', array(
	'type'        => 'repeater',
	'label'       => esc_attr__( 'TAB SECTION', 'awesome-theme' ),
	'section'     => 'more_features',
	'priority'    => 10,
	'settings'    => 'more_features_section',
	'default'     => array(
		array(
			'accordion_title' => esc_attr__( '', 'awesome-theme' ),
			'accordion_discription' => esc_attr__( '', 'awesome-theme' ),	
		),
		
	 ),
	'fields' =>array(
	
   'accordion_title' => array(
			'type'        => 'text',
			'label'       => __( 'ACCORDIAN TITLE', 'awesome-theme' ),
			'description' => __( 'set ACCORDIAN TITLE', 'awesome-theme' ),
			'help'        => __( 'set ACCORDIAN TITLE', 'awesome-theme' ),
			'default'     => '',
	
   ),
   'accordion_discription' => array(
			'type'        => 'text',
			'label'       => __( ' ACCORDIAN DISCRIPTION ', 'awesome-theme' ),
			'description' => __( 'set ACCORDIAN DISCRIPTION', 'awesome-theme' ),
			'help'        => __( 'set ACCORDIAN DISCRIPTION', 'awesome-theme' ),
			'default'     => '',
	
   ),
   
   )
	 
) );
Kirki::add_section( 'portifolio', array(
	'title'      => esc_attr__( 'PORTIFOLIO', 'awesome-theme' ),
	 'panel'          => '1st_panel',
	'priority'   => 2,
	'capability' => 'edit_theme_options',
	'description' => esc_attr__( 'MORE FEATURES SECTION', 'awesome-theme' ),
) );
Kirki::add_field( 'portifolio_tab_1st', array(
	'type'        => 'repeater',
	'label'       => esc_attr__( 'PORTIFOLIO', 'awesome-theme' ),
	'section'     => 'portifolio',
	'priority'    => 10,
	'settings'    => 'portifolio_tab_1st',
	'default'     => array(
		array(
			'portifolio_thumb' => esc_attr__( '', 'awesome-theme' ),
			'portifolio_disc' => esc_attr__( '', 'awesome-theme' ),
		),
		
	 ),
	'fields' =>array(
			'portifolio_thumb' => array(
			'type'        => 'image',
			'label'       => __( 'PORTIFOLIO THUMBNAIL', 'awesome-theme' ),
			'description' => __( 'set PORTIFOLIO THUMB', 'awesome-theme' ),
			'help'        => __( 'set PORTIFOLIO THUMBNAIL', 'awesome-theme' ),
			'default'     => '',
	
   ),
   'portifolio_disc' => array(
			'type'        => 'text',
			'label'       => __( 'PORTIFOLIO DISCRIPTION', 'awesome-theme' ),
			'description' => __( 'set PORTIFOLIO DISCRIPTION', 'awesome-theme' ),
			'help'        => __( 'set PORTIFOLIO DISCRIPTION', 'awesome-theme' ),
			'default'     => '',
	
   ),
   )
	 
) );




