<?php /* Template Name: Home Template */ ?>
<?php get_header() ; ?>

<!--START Section -->
<section>
  <div class="container-fluid">
    <div class="row">
      <div class="carousel fade-carousel slide" data-ride="carousel" data-interval="4000" id="bs-carousel"> 
        <!-- Overlay -->
        <div class="overlay"></div>
        
        <!-- Indicators -->
        <ol class="carousel-indicators">
          <li data-target="#bs-carousel" data-slide-to="0" class="active"></li>
          <li data-target="#bs-carousel" data-slide-to="1"></li>
          <li data-target="#bs-carousel" data-slide-to="2"></li>
        </ol>
        
        <!-- Wrapper for slides -->
        <div class="carousel-inner">
          <div class="item slides active">
            <div class="slide-1"></div>
            <div class="hero">
              <hgroup>
                <h1>We are creative</h1>
                <h2>Get start your next awesome project</h2>
              </hgroup>
              <button class="btn btn-hero btn-lg" role="button">See all features</button>
            </div>
          </div>
          <div class="item slides">
            <div class="slide-2"></div>
            <div class="hero">
              <hgroup>
                <h1>We are smart</h1>
                <h2>Get start your next awesome project</h2>
              </hgroup>
              <button class="btn btn-hero btn-lg" role="button">See all features</button>
            </div>
          </div>
          <div class="item slides">
            <div class="slide-3"></div>
            <div class="hero">
              <hgroup>
                <h1>We are amazing</h1>
                <h2>Get start your next awesome project</h2>
              </hgroup>
              <button class="btn btn-hero btn-lg" role="button">See all features</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- //  slider--> 
  </div>
  <!-- //  container-fluid -->
  <div class="container">
    <div class="row welcome">
    <?php $image = get_theme_mod( 'wel_thumb', '' ); ?>
      <div class="col-md-6 col-sm-12 col-xs-12 animated bounceInLeft ">
      <?php if($image) { ?>
      <img src="<?php echo esc_url( $image ); ?>" class="img-responsive" alt=""/>
     <?php } else { ?>
       <img src="<?php echo get_template_directory_uri() ; ?>/images/img001.jpg" class="img-responsive" alt=""/>
       <?php } ?>
       </div>
      <div class="col-md-6 col-sm-12 col-xs-12 animated bounceInRight ">
        <h3><span>   <?php echo $title = get_theme_mod( 'title', 'WELCOME TO AWESOME ONE' ); ?> </span></h3>
        <?php $disc = get_theme_mod( 'discription', '' ); ?>
        <?php if($disc) {
			
			echo $disc ;
		}
			else 
			{
			?>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eget molestie sapien. Duis in consectetur dolor, eu faucibus sapien. Nunc nunc est, tincidunt id enim non, aliquet gravida sem. Ut ut lacus pulvinar, hendrerit elit tempus, ullamcorper ante. Nulla leo metus, lacinia et leo non, sagittis suscipit tellus. Aenean at erat ac est ultricies aliquet. Suspendisse ut lacus feugiat, elementum turpis blandit, facilisis erat. Aenean convallis augue sed luctus molestie. Donec vel leo sed orci venenatis volutpat. Etiam non blandit urna, sit amet volutpat tortor. Morbi nec augue vitae diam convallis feugiat. Donec sed sem malesuada, venenatis lectus ut, mollis justo. Nam in dui malesuada, dapibus diam sit amet, ullamcorper risus. </p>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eget molestie sapien. Duis in consectetur dolor, eu faucibus sapien. Nunc nunc est, tincidunt id enim non, aliquet gravida sem. Ut ut lacus pulvinar, hendrerit elit tempus, ullamcorper ante.</p>
        
        <?php } ?>
      </div>
    </div>
  </div>
  <!-- //  containerof  Welcome to AWESOME ONE -->
  <div class=" container-fluid aboutUsWrap">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12 aboutUs animated fadeInUp">
          <h3><span> <?php echo $title = get_theme_mod( 'about_site', 'About AWESOME ONE' ); ?>  </span></h3>
           <?php 
		   
		   $repeater_value = get_theme_mod( 'about_site_sect', array() );
		  

// Check that we have something to process
 if ( ! empty( $repeater_value ) ) {

    // Loop all repeater rows
    foreach ( $repeater_value as $key => $row_values ) {
		
		 $title = $row_values['about_title'];
		  $desc = $row_values['about_disc'];
		  $icon = $row_values['about_icon'];
		
		?>
          <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="boxWrap">
              <h4><?php if( isset( $title ) ){ echo  $title ; } else {   ?> Web Design <?php } ; ?></h4>
              <p><?php if( isset( $disc  ) ){ echo  $disc ; } else {   ?> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eget molestie sapien. Duis in consectetur dolor, eu faucibus sapien. Nunc nunc est, tincidunt id enim non, aliquet gravida sem. Ut ut lacus pulvinar, hendrerit elit tempus, ullamcorper ante.  <?php } ; ?> </p>
              <div class="iconWrap"> <?php if( isset( $icon ) ) { ?> <img src="<?php  echo  $image_url  = wp_get_attachment_url($icon, 'awesome-theme'); ?> " width="79" height="69"  alt=""/> <?php }else { ?> <img src="<?php echo get_template_directory_uri() ; ?>/images/icon01.png" width="79" height="69"  alt=""/></div><?php } ; ?>  </div> 
            </div>
          </div>
          <?php 
		  
		   }
}  else {  ?>
          <!-- // boxWrap-->
           <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="boxWrap">
              <h4>Web Design</h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eget molestie sapien. Duis in consectetur dolor, eu faucibus sapien. Nunc nunc est, tincidunt id enim non, aliquet gravida sem. Ut ut lacus pulvinar, hendrerit elit tempus, ullamcorper ante. </p>
              <div class="iconWrap"><img src="<?php echo get_template_directory_uri() ; ?>/images/icon01.png" width="79" height="69"  alt=""/></div>
            </div>
          </div>
          <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="boxWrap">
              <h4>web development</h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eget molestie sapien. Duis in consectetur dolor, eu faucibus sapien. Nunc nunc est, tincidunt id enim non, aliquet gravida sem. Ut ut lacus pulvinar, hendrerit elit tempus, ullamcorper ante. </p>
              <div class="iconWrap"><img src="<?php echo get_template_directory_uri() ; ?>/images/icon02.png" width="79" height="69"  alt=""/></div>
            </div>
          </div>
          <!-- // boxWrap-->
          <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="boxWrap">
              <h4>SEO</h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eget molestie sapien. Duis in consectetur dolor, eu faucibus sapien. Nunc nunc est, tincidunt id enim non, aliquet gravida sem. Ut ut lacus pulvinar, hendrerit elit tempus, ullamcorper ante. </p>
              <div class="iconWrap"><img src="<?php echo get_template_directory_uri() ; ?>/images/icon03.png" width="79" height="69"  alt=""/></div>
            </div>
          </div>
          <!-- // boxWrap-->
          <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="boxWrap">
              <h4>e commerce solutions</h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eget molestie sapien. Duis in consectetur dolor, eu faucibus sapien. Nunc nunc est, tincidunt id enim non, aliquet gravida sem. Ut ut lacus pulvinar, hendrerit elit tempus, ullamcorper ante. </p>
              <div class="iconWrap"><img src="<?php echo get_template_directory_uri() ; ?>/images/icon04.png" width="79" height="69"  alt=""/></div>
            </div>
          </div>
          <!-- // boxWrap--> 
          <?php } ?>
        </div>
      </div>
      <!-- // row--> 
    </div>
    <!-- // container--> 
  </div>
  <!-- //  container of  About AWESOME ONE -->
  
  <!--<div class="container">
    <div class="row welcome">
      <div class="col-md-6 col-sm-12 col-xs-12 animated bounceInLeft">
        <h3><span>Who we Are</span></h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eget molestie sapien. Duis in consectetur dolor, eu faucibus sapien. Nunc nunc est, tincidunt id enim non, aliquet gravida sem. Ut ut lacus pulvinar, hendrerit elit tempus, ullamcorper ante. Nulla leo metus, lacinia et leo non, sagittis suscipit tellus. Aenean at erat ac est ultricies aliquet. Suspendisse ut lacus feugiat, elementum turpis blandit, facilisis erat. Aenean convallis augue sed luctus molestie. Donec vel leo sed orci venenatis volutpat. Etiam non blandit urna, sit amet volutpat tortor. Morbi nec augue vitae diam convallis feugiat. Donec sed sem malesuada, venenatis lectus ut, mollis justo. Nam in dui malesuada, dapibus diam sit amet, ullamcorper risus. </p>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eget molestie sapien. Duis in consectetur dolor, eu faucibus sapien. Nunc nunc est, tincidunt id enim non, aliquet gravida sem. Ut ut lacus pulvinar, hendrerit elit tempus, ullamcorper ante.</p>
      </div>
      <div class="col-md-6 col-sm-12 col-xs-12 animated fadeInDownBig"><img src="<?php echo get_template_directory_uri() ; ?>/images/img001.jpg" class="img-responsive" alt=""/></div>
    </div>
  </div> -->
  <!-- //  container of  Who we Are -->
  <div class=" container-fluid wrapper">
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-sm-12 col-xs-12 wrapCont">
          <h3><span>Why Choose us</span></h3>
          <!-- Nav tabs -->
          <div class="card">
            <ul class="nav nav-tabs" role="tablist">
              <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Quality</a></li>
              <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Design</a></li>
              <li role="presentation"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab">Programming</a></li>
            </ul>
            
            <!-- Tab panes -->
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active" id="home"> Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, lorem ipsum is simply dummy text of the printing and typesetting industry.
                <ul>
                  <li><i class="fa fa-chevron-circle-right"></i> Awesome Shortcodes</li>
                  <li><i class="fa fa-chevron-circle-right"></i> Browser Compatibility</li>
                  <li><i class="fa fa-chevron-circle-right"></i> Easy To Edit Animations</li>
                  <li><i class="fa fa-chevron-circle-right"></i> Many Home page Versions</li>
                  <li><i class="fa fa-chevron-circle-right"></i> Many Blog Pages</li>
                </ul>
              </div>
              <div role="tabpanel" class="tab-pane" id="profile">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an
                <ul>
                  <li><i class="fa fa-chevron-circle-right"></i> Easy To Edit Animations</li>
                  <li><i class="fa fa-chevron-circle-right"></i> Many Home page Versions</li>
                  <li><i class="fa fa-chevron-circle-right"></i> Awesome Shortcodes</li>
                  <li><i class="fa fa-chevron-circle-right"></i> Browser Compatibility</li>
                  <li><i class="fa fa-chevron-circle-right"></i> Many Blog Pages</li>
                </ul>
              </div>
              <div role="tabpanel" class="tab-pane" id="messages">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s. Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                <ul>
                  <li><i class="fa fa-chevron-circle-right"></i> Many Home page Versions</li>
                  <li><i class="fa fa-chevron-circle-right"></i> Many Blog Pages</li>
                  <li><i class="fa fa-chevron-circle-right"></i> Awesome Shortcodes</li>
                  <li><i class="fa fa-chevron-circle-right"></i> Browser Compatibility</li>
                  <li><i class="fa fa-chevron-circle-right"></i> Easy To Edit Animations</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-sm-12 col-xs-12 wrapCont">
          <h3><span>More Features</span></h3>
          <div class="panel-group" id="accordion1">
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"><a data-toggle="collapse" data-parent="#accordion1" href="#collapseOne"> <i class="fa fa-mobile"></i> 100% Responsive </a></h4>
              </div>
              <div id="collapseOne" class="panel-collapse collapse in">
                <div class="panel-body"> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eget molestie sapien. Duis in consectetur dolor, eu faucibus sapien. Nunc nunc est, tincidunt id enim non, aliquet gravida sem. Ut ut lacus pulvinar, hendrerit elit tempus, ullamcorper ante. </div>
              </div>
            </div>
            <!-- //panel-default -->
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"><a data-toggle="collapse" data-parent="#accordion1" href="#collapse2"> <i class="fa fa-link"></i> Extremely Flexble </a></h4>
              </div>
              <div id="collapse2" class="panel-collapse collapse">
                <div class="panel-body"> This is a simple accordion inner content... </div>
              </div>
            </div>
            <!-- //panel-default -->
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title"><a data-toggle="collapse" data-parent="#accordion1" href="#collapse3"> <i class="fa fa-thumbs-up"></i> Customer Satisfation </a></h4>
              </div>
              <div id="collapse3" class="panel-collapse collapse">
                <div class="panel-body"> This is a simple accordion inner content... </div>
              </div>
            </div>
            <!-- //panel-default --> 
          </div>
        </div>
      </div>
      <!-- // row--> 
    </div>
    <!-- // container--> 
  </div>
  <!-- //  container of  wrapper -->
  <div class="container">
    <div class="row workWrap">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="animated fadeInUp"><h3><span>Work We Did</span></h3>
        <span class="icon-title"> <span></span> <i class="fa fa-star"></i></span></div>
        <ul class="nav nav-tabs">
          <li class="active"><a data-toggle="tab" href="#tab11">All</a></li>
          <li><a data-toggle="tab" href="#tab21">Wordpress</a></li>
          <li><a data-toggle="tab" href="#tab31">Web Devlopment</a></li>
          <li><a data-toggle="tab" href="#tab41">Web Design</a></li>
          <li><a data-toggle="tab" href="#tab51">ECommerce</a></li>
        </ul>
        <div class="clearfix"></div>
        <div class="tab-content">
          <div class="grid tab-pane fade in active" id="tab11">
            <div class="col-md-4 col-sm-6 col-xs-12">
              <figure class="effect-zoe"> <img src="<?php echo get_template_directory_uri() ; ?>/images/25.jpg" class="img-responsive" alt="img25"/>
                <figcaption>
                  <h2>Creative <span>Zoe</span></h2>
                  <p class="icon-links"> <a href="#"><i class="fa fa-search"></i></a> <a href="#"><i class="fa fa-link"></i></a> </p>
                </figcaption>
              </figure>
            </div>
            <!-- // Img BOX -->
            <div class="col-md-4 col-sm-6 col-xs-12">
              <figure class="effect-zoe"> <img src="<?php echo get_template_directory_uri() ; ?>/images/25.jpg" class="img-responsive" alt="img25"/>
                <figcaption>
                  <h2>Creative <span>Zoe</span></h2>
                  <p class="icon-links"> <a href="#"><i class="fa fa-search"></i></a> <a href="#"><i class="fa fa-link"></i></a> </p>
                </figcaption>
              </figure>
            </div>
            <!-- // Img BOX -->
            <div class="col-md-4 col-sm-6 col-xs-12">
              <figure class="effect-zoe"> <img src="<?php echo get_template_directory_uri() ; ?>/images/25.jpg" class="img-responsive" alt="img25"/>
                <figcaption>
                  <h2>Creative <span>Zoe</span></h2>
                  <p class="icon-links"> <a href="#"><i class="fa fa-search"></i></a> <a href="#"><i class="fa fa-link"></i></a> </p>
                </figcaption>
              </figure>
            </div>
            <!-- // Img BOX --> 
            
          </div>
          <!-- // tab11 -->
          <div class="grid tab-pane fade" id="tab21">
            <div class="col-md-4 col-sm-6 col-xs-12">
              <figure class="effect-zoe"> <img src="<?php echo get_template_directory_uri() ; ?>/images/25.jpg" class="img-responsive" alt="img25"/>
                <figcaption>
                  <h2>Creative <span>Zoe</span></h2>
                  <p class="icon-links"> <a href="#"><i class="fa fa-search"></i></a> <a href="#"><i class="fa fa-link"></i></a> </p>
                </figcaption>
              </figure>
            </div>
            <!-- // Img BOX -->
            <div class="col-md-4 col-sm-6 col-xs-12">
              <figure class="effect-zoe"> <img src="<?php echo get_template_directory_uri() ; ?>/images/25.jpg" class="img-responsive" alt="img25"/>
                <figcaption>
                  <h2>Creative <span>Zoe</span></h2>
                  <p class="icon-links"> <a href="#"><i class="fa fa-search"></i></a> <a href="#"><i class="fa fa-link"></i></a> </p>
                </figcaption>
              </figure>
            </div>
            <!-- // Img BOX -->
            <div class="col-md-4 col-sm-6 col-xs-12">
              <figure class="effect-zoe"> <img src="<?php echo get_template_directory_uri() ; ?>/images/25.jpg" class="img-responsive" alt="img25"/>
                <figcaption>
                  <h2>Creative <span>Zoe</span></h2>
                  <p class="icon-links"> <a href="#"><i class="fa fa-search"></i></a> <a href="#"><i class="fa fa-link"></i></a> </p>
                </figcaption>
              </figure>
            </div>
            <!-- // Img BOX -->
            <div class="col-md-4 col-sm-6 col-xs-12">
              <figure class="effect-zoe"> <img src="<?php echo get_template_directory_uri() ; ?>/images/25.jpg" class="img-responsive" alt="img25"/>
                <figcaption>
                  <h2>Creative <span>Zoe</span></h2>
                  <p class="icon-links"> <a href="#"><i class="fa fa-search"></i></a> <a href="#"><i class="fa fa-link"></i></a> </p>
                </figcaption>
              </figure>
            </div>
            <!-- // Img BOX --> 
            
          </div>
          <!-- // tab21 -->
          <div class="grid tab-pane fade" id="tab31">
            <div class="col-md-4 col-sm-6 col-xs-12">
              <figure class="effect-zoe"> <img src="<?php echo get_template_directory_uri() ; ?>/images/25.jpg" class="img-responsive" alt="img25"/>
                <figcaption>
                  <h2>Creative <span>Zoe</span></h2>
                  <p class="icon-links"> <a href="#"><i class="fa fa-search"></i></a> <a href="#"><i class="fa fa-link"></i></a> </p>
                </figcaption>
              </figure>
            </div>
            <!-- // Img BOX -->
            <div class="col-md-4 col-sm-6 col-xs-12">
              <figure class="effect-zoe"> <img src="<?php echo get_template_directory_uri() ; ?>/images/25.jpg" class="img-responsive" alt="img25"/>
                <figcaption>
                  <h2>Creative <span>Zoe</span></h2>
                  <p class="icon-links"> <a href="#"><i class="fa fa-search"></i></a> <a href="#"><i class="fa fa-link"></i></a> </p>
                </figcaption>
              </figure>
            </div>
            <!-- // Img BOX -->
            <div class="col-md-4 col-sm-6 col-xs-12">
              <figure class="effect-zoe"> <img src="<?php echo get_template_directory_uri() ; ?>/images/25.jpg" class="img-responsive" alt="img25"/>
                <figcaption>
                  <h2>Creative <span>Zoe</span></h2>
                  <p class="icon-links"> <a href="#"><i class="fa fa-search"></i></a> <a href="#"><i class="fa fa-link"></i></a> </p>
                </figcaption>
              </figure>
            </div>
            <!-- // Img BOX --> 
            
          </div>
          <!-- // tab31 -->
          <div class="grid tab-pane fade" id="tab41">
            <div class="col-md-4 col-sm-6 col-xs-12">
              <figure class="effect-zoe"> <img src="<?php echo get_template_directory_uri() ; ?>/images/25.jpg" class="img-responsive" alt="img25"/>
                <figcaption>
                  <h2>Creative <span>Zoe</span></h2>
                  <p class="icon-links"> <a href="#"><i class="fa fa-search"></i></a> <a href="#"><i class="fa fa-link"></i></a> </p>
                </figcaption>
              </figure>
            </div>
            <!-- // Img BOX -->
            <div class="col-md-4 col-sm-6 col-xs-12">
              <figure class="effect-zoe"> <img src="<?php echo get_template_directory_uri() ; ?>/images/25.jpg" class="img-responsive" alt="img25"/>
                <figcaption>
                  <h2>Creative <span>Zoe</span></h2>
                  <p class="icon-links"> <a href="#"><i class="fa fa-search"></i></a> <a href="#"><i class="fa fa-link"></i></a> </p>
                </figcaption>
              </figure>
            </div>
            <!-- // Img BOX -->
            <div class="col-md-4 col-sm-6 col-xs-12">
              <figure class="effect-zoe"> <img src="<?php echo get_template_directory_uri() ; ?>/images/25.jpg" class="img-responsive" alt="img25"/>
                <figcaption>
                  <h2>Creative <span>Zoe</span></h2>
                  <p class="icon-links"> <a href="#"><i class="fa fa-search"></i></a> <a href="#"><i class="fa fa-link"></i></a> </p>
                </figcaption>
              </figure>
            </div>
            <!-- // Img BOX -->
            <div class="col-md-4 col-sm-6 col-xs-12">
              <figure class="effect-zoe"> <img src="<?php echo get_template_directory_uri() ; ?>/images/25.jpg" class="img-responsive" alt="img25"/>
                <figcaption>
                  <h2>Creative <span>Zoe</span></h2>
                  <p class="icon-links"> <a href="#"><i class="fa fa-search"></i></a> <a href="#"><i class="fa fa-link"></i></a> </p>
                </figcaption>
              </figure>
            </div>
            <!-- // Img BOX -->
            <div class="col-md-4 col-sm-6 col-xs-12">
              <figure class="effect-zoe"> <img src="<?php echo get_template_directory_uri() ; ?>/images/25.jpg" class="img-responsive" alt="img25"/>
                <figcaption>
                  <h2>Creative <span>Zoe</span></h2>
                  <p class="icon-links"> <a href="#"><i class="fa fa-search"></i></a> <a href="#"><i class="fa fa-link"></i></a> </p>
                </figcaption>
              </figure>
            </div>
            <!-- // Img BOX --> 
            
          </div>
          <!-- // tab41 -->
          <div class="grid tab-pane fade" id="tab51">
            <div class="col-md-4 col-sm-6 col-xs-12">
              <figure class="effect-zoe"> <img src="<?php echo get_template_directory_uri() ; ?>/images/25.jpg" class="img-responsive" alt="img25"/>
                <figcaption>
                  <h2>Creative <span>Zoe</span></h2>
                  <p class="icon-links"> <a href="#"><i class="fa fa-search"></i></a> <a href="#"><i class="fa fa-link"></i></a> </p>
                </figcaption>
              </figure>
            </div>
            <!-- // Img BOX -->
            <div class="col-md-4 col-sm-6 col-xs-12">
              <figure class="effect-zoe"> <img src="<?php echo get_template_directory_uri() ; ?>/images/25.jpg" class="img-responsive" alt="img25"/>
                <figcaption>
                  <h2>Creative <span>Zoe</span></h2>
                  <p class="icon-links"> <a href="#"><i class="fa fa-search"></i></a> <a href="#"><i class="fa fa-link"></i></a> </p>
                </figcaption>
              </figure>
            </div>
            <!-- // Img BOX -->
            <div class="col-md-4 col-sm-6 col-xs-12">
              <figure class="effect-zoe"> <img src="<?php echo get_template_directory_uri() ; ?>/images/25.jpg" class="img-responsive" alt="img25"/>
                <figcaption>
                  <h2>Creative <span>Zoe</span></h2>
                  <p class="icon-links"> <a href="#"><i class="fa fa-search"></i></a> <a href="#"><i class="fa fa-link"></i></a> </p>
                </figcaption>
              </figure>
            </div>
            <!-- // Img BOX -->
            <div class="col-md-4 col-sm-6 col-xs-12">
              <figure class="effect-zoe"> <img src="<?php echo get_template_directory_uri() ; ?>/images/25.jpg" class="img-responsive" alt="img25"/>
                <figcaption>
                  <h2>Creative <span>Zoe</span></h2>
                  <p class="icon-links"> <a href="#"><i class="fa fa-search"></i></a> <a href="#"><i class="fa fa-link"></i></a> </p>
                </figcaption>
              </figure>
            </div>
            <!-- // Img BOX --> 
            
          </div>
          <!-- // tab51 --> 
        </div>
        <!-- // tab-content --> 
      </div>
    </div>
  </div>
  <!-- //workWrap  -->
  
  <div class="testimonial">
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center">
          <h3>What Clients Said</h3>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="carousel slide" data-ride="carousel" id="quote-carousel"> 
            <!-- Bottom Carousel Indicators -->
            <ol class="carousel-indicators">
              <li data-target="#quote-carousel" data-slide-to="0" class="active"></li>
              <li data-target="#quote-carousel" data-slide-to="1"></li>
              <li data-target="#quote-carousel" data-slide-to="2"></li>
            </ol>
            
            <!-- Carousel Slides / Quotes -->
            <div class="carousel-inner"> 
              
              <!-- Quote 1 -->
			  /*
			  
			   <?php   $testimonial = get_theme_mod( 'testimonial', array() );
   
   
   if ( ! empty( $testimonial ) ) {

    // Loop all repeater rows
    foreach ( $testimonial as $key => $row_values ) {
		
		 $c_say = $row_values['client_say'];
		 $c_name = $row_values['client_name'];
		 $c_prof = $row_values['client_prof'];
		
		 
		?>
		<div class="item active">
		<div class="col-md-6">
                  <blockquote>
                    <div class="row">
                      <div class="col-sm-3 text-center"> <?php if( isset( $c_prof ) ) { ?> <img class="img-circle" src="<?php  echo  $image_url  = wp_get_attachment_url($c_prof, 'awesome-theme'); ?>" alt="" style="width: 100px;height:100px;"> <?php } else { ?><img class="img-circle" src="<?php echo get_template_directory_uri() ; ?>/twitter/mijustin/128.jpg" alt="" style="width: 100px;height:100px;"> <?php } ?> </div>
                      <div class="col-sm-9">
                        <p><?php  if( isset(  $c_say ) ){ echo   $c_say ; } else {   ?>  Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit! <?php } ; ?> </p> 
                        <small><?php  if( isset(  $c_name) ){ echo   $c_name  ; } else {   ?>  Someone famous <?php } ?>  </small> </div>
                    </div>
                  </blockquote>
                </div>
				</div>
		<?php 
		   }
}  else {  ?>




  <?php  } ?>
			  
			  */
              <div class="item active">
                <div class="col-md-6">
                  <blockquote>
                    <div class="row">
                      <div class="col-sm-3 text-center"> <img class="img-circle" src="twitter/mijustin/128.jpg" alt="" style="width: 100px;height:100px;"> </div>
                      <div class="col-sm-9">
                        <p>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit!</p>
                        <small>Someone famous</small> </div>
                    </div>
                  </blockquote>
                </div>
                <div class="col-md-6">
                  <blockquote>
                    <div class="row">
                      <div class="col-sm-3 text-center"> <img class="img-circle" src="twitter/keizgoesboom/128.jpg" alt="" style="width: 100px;height:100px;"> </div>
                      <div class="col-sm-9">
                        <p>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit!</p>
                        <small>Someone famous</small> </div>
                    </div>
                  </blockquote>
                </div>
              </div>
              <!-- Quote 2 -->
              <div class="item">
                <div class="col-md-6">
                  <blockquote>
                    <div class="row">
                      <div class="col-sm-3 text-center"> <img class="img-circle" src="twitter/kolage/128.jpg" alt="" style="width: 100px;height:100px;"> </div>
                      <div class="col-sm-9">
                        <p>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit!</p>
                        <small>Someone famous</small> </div>
                    </div>
                  </blockquote>
                </div>
                <div class="col-md-6">
                  <blockquote>
                    <div class="row">
                      <div class="col-sm-3 text-center"> <img class="img-circle" src="twitter/keizgoesboom/128.jpg"  alt="" style="width: 100px;height:100px;"> </div>
                      <div class="col-sm-9">
                        <p>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit!</p>
                        <small>Someone famous</small> </div>
                    </div>
                  </blockquote>
                </div>
              </div>
              <!-- Quote 3 -->
              <div class="item">
                <div class="col-md-6">
                  <blockquote>
                    <div class="row">
                      <div class="col-sm-3 text-center"> <img class="img-circle" src="twitter/mijustin/128.jpg" alt="" style="width: 100px;height:100px;"> </div>
                      <div class="col-sm-9">
                        <p>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit!</p>
                        <small>Someone famous</small> </div>
                    </div>
                  </blockquote>
                </div>
                <div class="col-md-6">
                  <blockquote>
                    <div class="row">
                      <div class="col-sm-3 text-center"> <img class="img-circle" src="twitter/kolage/128.jpg" alt="" style="width: 100px;height:100px;"> </div>
                      <div class="col-sm-9">
                        <p>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit!</p>
                        <small>Someone famous</small> </div>
                    </div>
                  </blockquote>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- //testimonial  -->
  <div class="container">
    <div class="row blogWrap">
      <div class="col-md-12 col-sm-12 col-xs-12 animated fadeInUp">
        <h3><span>Our Blog</span></h3>
        <span class="icon-title"> <span></span> <i class="fa fa-star"></i></span> </div>
      <div class="col-md-6 animated bounceInLeft">
        <div class="blog-area"><img src="<?php echo get_template_directory_uri() ; ?>/images/bimg01.jpg" width="600" height="320"  class="img-responsive"  alt=""/>
          <div class="caption">Lorem ipsum dolor sit amet, consectetur adipisicing elitr eicien</div>
        </div>
        <div class="row">
          <div class="col-md-2 col-sm-2 col-xs-3"><img src="<?php echo get_template_directory_uri() ; ?>/images/img01.jpg" width="74" height="52"  alt=""/></div>
          <div class="col-md-10 col-sm-10 col-xs-9">Maecenas eget molestie sapien. Duis in consectetur dolor, eu faucibus sapien. Nunc nunc est, tincidunt id enim non</div>
        </div>
        <div class="row">
          <div class="col-md-2 col-sm-2 col-xs-3"><img src="<?php echo get_template_directory_uri() ; ?>/images/img01.jpg" width="74" height="52"  alt=""/></div>
          <div class="col-md-10 col-sm-10 col-xs-9">Maecenas eget molestie sapien. Duis in consectetur dolor, eu faucibus sapien. Nunc nunc est, tincidunt id enim non</div>
        </div>
        <div class="row">
          <div class="col-md-2 col-sm-2 col-xs-3"><img src="<?php echo get_template_directory_uri() ; ?>/images/img01.jpg" width="74" height="52"  alt=""/></div>
          <div class="col-md-10 col-sm-10 col-xs-9">Maecenas eget molestie sapien. Duis in consectetur dolor, eu faucibus sapien. Nunc nunc est, tincidunt id enim non</div>
        </div>
        <div class="row">
          <div class="col-md-2 col-sm-2 col-xs-3"><img src="<?php echo get_template_directory_uri() ; ?>/images/img01.jpg" width="74" height="52"  alt=""/></div>
          <div class="col-md-10 col-sm-10 col-xs-9">Maecenas eget molestie sapien. Duis in consectetur dolor, eu faucibus sapien. Nunc nunc est, tincidunt id enim non</div>
        </div>
      </div>
      <!-- // bLOG lEFT -->
      
      <div class="col-md-6 animated bounceInRight">
        <div class="blog-area"><img src="<?php echo get_template_directory_uri() ; ?>/images/bimg01.jpg" width="600" height="320"  class="img-responsive"  alt=""/>
          <div class="caption">Lorem ipsum dolor sit amet, consectetur adipisicing elitr eicien</div>
        </div>
        <div class="row">
          <div class="col-md-2 col-sm-2 col-xs-3"><img src="<?php echo get_template_directory_uri() ; ?>/images/img01.jpg" width="74" height="52"  alt=""/></div>
          <div class="col-md-10 col-sm-10 col-xs-9">Maecenas eget molestie sapien. Duis in consectetur dolor, eu faucibus sapien. Nunc nunc est, tincidunt id enim non</div>
        </div>
        <div class="row">
          <div class="col-md-2 col-sm-2 col-xs-3"><img src="<?php echo get_template_directory_uri() ; ?>/images/img01.jpg" width="74" height="52"  alt=""/></div>
          <div class="col-md-10 col-sm-10 col-xs-9">Maecenas eget molestie sapien. Duis in consectetur dolor, eu faucibus sapien. Nunc nunc est, tincidunt id enim non</div>
        </div>
        <div class="row">
          <div class="col-md-2 col-sm-2 col-xs-3"><img src="<?php echo get_template_directory_uri() ; ?>/images/img01.jpg" width="74" height="52"  alt=""/></div>
          <div class="col-md-10 col-sm-10 col-xs-9">Maecenas eget molestie sapien. Duis in consectetur dolor, eu faucibus sapien. Nunc nunc est, tincidunt id enim non</div>
        </div>
        <div class="row">
          <div class="col-md-2 col-sm-2 col-xs-3"><img src="<?php echo get_template_directory_uri() ; ?>/images/img01.jpg" width="74" height="52"  alt=""/></div>
          <div class="col-md-10 col-sm-10 col-xs-9">Maecenas eget molestie sapien. Duis in consectetur dolor, eu faucibus sapien. Nunc nunc est, tincidunt id enim non</div>
        </div>
        <!-- // bLOG lEFT --></div>
    </div>
    <!-- // Blog --> 
  </div>
  <div class="container-fluid teamWrap">
    <div class="container">
      <div class="row animated fadeInUp">
        <h3>Meet Our Team</h3>
        <span class="icon-title"> <span></span> <i class="fa fa-star"></i></span> </div>
      <div class="row animated fadeInUpBig">
        <div class="col-md-3 col-sm-6">
          <div class="teamCont">
            <h4><?php echo $TEAM_NAME = get_theme_mod( 'team_name', 'TEAM NAME' ); ?></h4>
            <h5><?php echo $TEAM_NAME = get_theme_mod( 'founder', 'Founder & CEO' ); ?>  </h5> team_details
            <p><?php echo $TEAM_NAME = get_theme_mod( 'team_details', 'team details' ); ?> Maecenas eget molestie sapien. Duis in consectetur dolor, eu faucibus sapien. Nunc nunc est, tincidunt id enim non Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</p>
            <div class="slink"> <a href="#"><i class="fa fa-facebook"></i></a> <a href="#"><i class="fa fa-twitter"></i></a> <a href="#"><i class="fa fa-google-plus"></i></a> <a href="#"><i class="fa fa-linkedin"></i></a></div>
            <div class="fprof"><a href="#"><i class="fa fa-arrow-right"></i> Full Profile</a></div>
          </div>
        </div>
        <!--  //  teamCont -->
		
 <?php   $team_member = get_theme_mod( 'team_member', array() );
   
   
   if ( ! empty( $team_member ) ) {

    // Loop all repeater rows
    foreach ( $team_member as $key => $row_values ) {
		
		 $team_thumb = $row_values['team_member_thumb'];
		 $team_name = $row_values['team_member_name'];
		 $team_desgi = $row_values['team_member_desgi'];
		
		 
		?>
		
		
		 <div class="col-md-3 col-sm-6">
          <div class="thumbnail text-center"> <?php if( isset( $team_thumb ) ) { ?>  <img src="<?php  echo  $image_url  = wp_get_attachment_url($team_thumb, 'awesome-theme'); ?>"  alt=""/><?php } else { ?>  <img src="<?php echo get_template_directory_uri() ; ?>/images/123.jpg" class="img-circle"  alt=""/> <?php } ?>
            <h4> <?php  if( isset(  $team_name ) ){ echo   $team_name ; } else {   ?>  Team Name <?php } ; ?></h4>
            <h5><?php  if( isset(  $team_desgi ) ){ echo   $team_desgi ; } else {   ?>  Co-Founder <?php } ; ?></h5>
          </div>
        </div>
		<?php 
		   }
}  else {  ?>

 <div class="col-md-3 col-sm-6">
          <div class="thumbnail text-center"> <img src="<?php echo get_template_directory_uri() ; ?>/images/123.jpg" class="img-circle"  alt=""/>
            <h4>Team Name</h4>
            <h5>Co-Founder</h5>
          </div>
        </div>
        <!--  //  teamMenber -->
        <div class="col-md-3 col-sm-6">
          <div class="thumbnail text-center"> <img src="<?php echo get_template_directory_uri() ; ?>/images/123.jpg" class="img-circle"  alt=""/>
            <h4>Team Name</h4>
            <h5>Business Development Manager</h5>
          </div>
        </div>
        <!--  //  teamMenber -->
        <div class="col-md-3 col-sm-6">
          <div class="thumbnail text-center"> <img src="<?php echo get_template_directory_uri() ; ?>/images/123.jpg" class="img-circle"  alt=""/>
            <h4>Team Name</h4>
            <h5>Senior Developer</h5>
          </div>
        </div>

 <?php  } ?>
		
		
		
       <!-- <div class="col-md-3 col-sm-6">
          <div class="thumbnail text-center"> <img src="<?php echo get_template_directory_uri() ; ?>/images/123.jpg" class="img-circle"  alt=""/>
            <h4>Team Name</h4>
            <h5>Co-Founder</h5>
          </div>
        </div>
       
        <div class="col-md-3 col-sm-6">
          <div class="thumbnail text-center"> <img src="<?php echo get_template_directory_uri() ; ?>/images/123.jpg" class="img-circle"  alt=""/>
            <h4>Team Name</h4>
            <h5>Business Development Manager</h5>
          </div>
        </div>
     
        <div class="col-md-3 col-sm-6">
          <div class="thumbnail text-center"> <img src="<?php echo get_template_directory_uri() ; ?>/images/123.jpg" class="img-circle"  alt=""/>
            <h4>Team Name</h4>
            <h5>Senior Developer</h5>
          </div>
        </div> -->
       
      </div>
    </div>
  </div>
  <!-- // teamWrap -->
  <div class="container clientWrap">
    <div class="col-md-12">
      <h3><span>Our Happy Clients</span></h3>
    </div>
    <div class="col-md-12">
      <div class="owl-carousel">
       <?php 
		   
		   $brand_logo = get_theme_mod( 'barand_logo', array() );
		  

// Check that we have something to process
 if ( ! empty( $brand_logo ) ) {

    // Loop all repeater rows
    foreach ( $brand_logo as $key => $row_values ) {
		
		 $logo = $row_values['brand_logo'];
		?>
        <div class="center-block"><a href="#" target="_blank"><img src=" <?php if( isset( $logo ) ) { ?> <img src="<?php  echo  $image_url  = wp_get_attachment_url($logo, 'awesome-theme'); ?>  " width="180" height="130" alt="" class="img-responsive thumbnail"/> <?php } else { ?> <img src="<?php echo get_template_directory_uri() ; ?>/images/logo01.jpg" width="180" height="130" alt="" class="img-responsive thumbnail"/> <?php } ?></a></div>
         <?php 
		   }
}  else {  ?>
        <div class="center-block"><a href="#" target="_blank"><img src="<?php echo get_template_directory_uri() ; ?>/images/logo01.jpg" width="180" height="130" alt="" class="img-responsive thumbnail"/></a></div>
        <div class="center-block"><a href="#" target="_blank"><img src="<?php echo get_template_directory_uri() ; ?>/images/logo02.jpg" width="180" height="130" alt="" class="img-responsive thumbnail"/></a></div>
        <div class="center-block"><a href="#" target="_blank"><img src="<?php echo get_template_directory_uri() ; ?>/images/logo03.jpg" width="180" height="130" alt="" class="img-responsive thumbnail"/></a></div>
        <div class="center-block"><a href="#" target="_blank"><img src="<?php echo get_template_directory_uri() ; ?>/images/logo04.jpg" width="180" height="130" alt="" class="img-responsive thumbnail"/></a></div>
        <div class="center-block"><a href="#" target="_blank"><img src="<?php echo get_template_directory_uri() ; ?>/images/logo05.jpg" width="180" height="130" alt="" class="img-responsive thumbnail"/></a></div>
        <div class="center-block"><a href="#" target="_blank"><img src="<?php echo get_template_directory_uri() ; ?>/images/logo06.jpg" width="180" height="130" alt="" class="img-responsive thumbnail"/></a></div>
        <div class="center-block"><a href="#" target="_blank"><img src="<?php echo get_template_directory_uri() ; ?>/images/logo01.jpg" width="180" height="130" alt="" class="img-responsive thumbnail"/></a></div>
        <div class="center-block"><a href="#" target="_blank"><img src="<?php echo get_template_directory_uri() ; ?>/images/logo02.jpg" width="180" height="130" alt="" class="img-responsive thumbnail"/></a></div>
        <div class="center-block"><a href="#" target="_blank"><img src="<?php echo get_template_directory_uri() ; ?>/images/logo03.jpg" width="180" height="130" alt="" class="img-responsive thumbnail"/></a></div>
      </div>
      <?php  } ?>
    </div>
  </div>
  <!-- // clientWrap --> 
</section>
<!--END MidSection --> 
<?php get_footer() ;?>