<?php
/**
 * The sidebar containing the main widget area.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package awesome_theme
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
?> 


<div class="col-md-3 col-sm-4">
      <!-- <div class="sidebar">
          <h3>Search</h3>

          <form class="input-group" action="#" method="get">
            <input type="text" class="form-control" name="q" placeholder="Search">
            <span class="input-group-btn">
            <button class="btn btn-default"><i class="fa fa-search"></i></button>
            </span>
          </form>
        </div>
        
        
        <div class="sidebar">
          <h3>Categories</h3>
          <ul class="sidebar-list">
            <li><i class="fa fa-angle-right"></i><a href="#">Architecture Design (50)</a></li>
            <li><i class="fa fa-angle-right"></i><a href="#">Project Management (20)</a></li>
            <li><i class="fa fa-angle-right"></i><a href="#">3D Design (10)</a></li>
            <li><i class="fa fa-angle-right"></i><a href="#">Interior Design (5)</a></li>
          </ul>
        </div>
       
        <div class="sidebar">
          <h3>Recent Posts</h3>
          <div class="sidebar-post clearfix"> <img src="<?php echo get_template_directory_uri() ; ?>/images/post1.jpg" alt="">
            <p>Lorem ipsum dolor sit amet.</p>
            <p><span><a href="#">2016/05/12</a></span></p>
          </div>
        
          <div class="sidebar-post clearfix"> <img src="<?php echo get_template_directory_uri() ; ?>/images/post2.jpg" alt="">
            <p>Lorem ipsum dolor sit amet.</p>
            <p><span><a href="#">2016/05/11</a></span></p>
          </div>

          <div class="sidebar-post clearfix"> <img src="<?php echo get_template_directory_uri() ; ?>/images/post3.jpg" alt="">
            <p>Lorem ipsum dolor sit amet.</p>
            <p><span><a href="#">2016/05/10</a></span></p>
          </div>
        
        </div>-->
        <?php dynamic_sidebar( 'sidebar-1' ); ?>
      </div>