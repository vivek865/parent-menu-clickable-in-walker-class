<?php
$config['site_name'] = 'My awesome site';