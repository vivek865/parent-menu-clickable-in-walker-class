<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-10-31 16:54:32 --> 404 Page Not Found --> http://cms:8888/article/7/Jeff-Vader-autographs
ERROR - 2012-10-31 17:02:54 --> 404 Page Not Found --> http://cms:8888/test
ERROR - 2012-10-31 17:04:09 --> 404 Page Not Found --> contact
ERROR - 2012-10-31 17:04:13 --> 404 Page Not Found --> about
ERROR - 2012-10-31 17:07:03 --> 404 Page Not Found --> http://cms:8888/article/7/Jeff-Vader-autographs
ERROR - 2012-10-31 17:07:53 --> 404 Page Not Found --> http://cms:8888/article/index/7/Jeff-Vader-autographs
ERROR - 2012-10-31 17:07:59 --> 404 Page Not Found --> http://cms:8888/article/7/Jeff-Vader-autographs
ERROR - 2012-10-31 17:08:05 --> 404 Page Not Found --> http://cms:8888/test
ERROR - 2012-10-31 17:13:13 --> 404 Page Not Found --> http://cms:8888/article/7/Jeff-Vader-autographs
ERROR - 2012-10-31 17:13:43 --> 404 Page Not Found --> http://cms:8888/article/7/Jeff-Vader-autographs
ERROR - 2012-10-31 17:19:16 --> 404 Page Not Found --> http://cms:8888/article/7/Jeff-Vader-autographs
ERROR - 2012-10-31 17:19:59 --> 404 Page Not Found --> http://cms:8888/article/7/Jeff-Vader-autographs
ERROR - 2012-10-31 17:19:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php:103) /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/system/core/Common.php 442
ERROR - 2012-10-31 17:20:05 --> 404 Page Not Found --> http://cms:8888/test
ERROR - 2012-10-31 17:20:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php:103) /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/system/core/Common.php 442
ERROR - 2012-10-31 17:53:04 --> 404 Page Not Found --> http://cms:8888/article/7/Jeff-Vader-autographs
ERROR - 2012-10-31 18:00:15 --> 404 Page Not Found --> http://cms:8888/test
ERROR - 2012-10-31 18:00:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php:103) /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/system/core/Common.php 442
ERROR - 2012-10-31 18:03:15 --> 404 Page Not Found --> http://cms:8888/article
ERROR - 2012-10-31 18:03:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php:103) /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/system/core/Common.php 442
ERROR - 2012-10-31 18:03:41 --> 404 Page Not Found --> http://cms:8888/article
ERROR - 2012-10-31 18:03:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php:103) /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/system/core/Common.php 442
ERROR - 2012-10-31 18:07:10 --> 404 Page Not Found --> http://cms:8888/article/7/Jeff-Vader-autographs
ERROR - 2012-10-31 18:07:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php:103) /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/system/core/Common.php 442
ERROR - 2012-10-31 18:08:04 --> 404 Page Not Found --> http://cms:8888/article/7/Jeff-Vader-autographs
ERROR - 2012-10-31 18:08:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php:103) /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/system/core/Common.php 442
ERROR - 2012-10-31 18:08:08 --> 404 Page Not Found --> http://cms:8888/article/7/Jeff-Vader-autographs
ERROR - 2012-10-31 18:08:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php:103) /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/system/core/Common.php 442
