<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-11-02 15:14:23 --> 404 Page Not Found --> http://cms:8888/admin/article/edit2
ERROR - 2012-11-02 15:14:32 --> 404 Page Not Found --> http://cms:8888/admin/article/edit2
ERROR - 2012-11-02 15:32:20 --> 404 Page Not Found --> http://cms:8888/admin/article/edit2
ERROR - 2012-11-02 15:45:08 --> Severity: Notice  --> Undefined variable: page /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/controllers/page.php 14
ERROR - 2012-11-02 15:45:08 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/controllers/page.php 14
ERROR - 2012-11-02 15:45:08 --> Severity: Notice  --> Undefined index: meta_title /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php 6
ERROR - 2012-11-02 15:45:19 --> Severity: Notice  --> Undefined index: meta_title /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php 6
