<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-11-01 11:57:31 --> 404 Page Not Found --> article/700/Jeff-Vader-autographs
ERROR - 2012-11-01 12:03:19 --> 404 Page Not Found --> article/700/Jeff-Vader-autographs
ERROR - 2012-11-01 12:03:35 --> 404 Page Not Found --> article/700/Jeff-Vader-autographs
ERROR - 2012-11-01 16:21:42 --> Severity: Notice  --> Undefined variable: articles /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/views/sidebar.php 2
ERROR - 2012-11-01 16:21:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php 20
ERROR - 2012-11-01 18:24:53 --> Severity: Notice  --> Undefined property: stdClass::$pubdate /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/views/templates/page.php 5
ERROR - 2012-11-01 18:26:46 --> Severity: Notice  --> Undefined property: stdClass::$pubdate /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/views/templates/page.php 5
ERROR - 2012-11-01 18:27:07 --> Severity: Notice  --> Undefined property: stdClass::$pubdate /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/views/templates/page.php 5
ERROR - 2012-11-01 18:36:36 --> 404 Page Not Found --> http://cms:8888/adin
ERROR - 2012-11-01 19:08:03 --> 404 Page Not Found --> http://cms:8888/amdin
ERROR - 2012-11-01 23:51:53 --> Severity: Notice  --> Undefined property: Dashboard::$article_m /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/controllers/admin/dashboard.php 10
