<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-10-30 00:28:25 --> Severity: Notice  --> Undefined variable: articles /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/views/templates/news_archive.php 16
ERROR - 2012-10-30 00:28:25 --> Severity: Warning  --> array_slice() expects parameter 1 to be array, null given /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/views/templates/news_archive.php 16
ERROR - 2012-10-30 00:28:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/helpers/cms_helper.php 20
ERROR - 2012-10-30 09:30:03 --> 404 Page Not Found --> http://cms:8888/news_archive
ERROR - 2012-10-30 10:14:17 --> Severity: Notice  --> Undefined property: Page::$article_m /Applications/MAMP/htdocs/envato_building_a_cms_with_codeigniter/application/controllers/page.php 68
ERROR - 2012-10-30 11:13:35 --> 404 Page Not Found --> http://cms:8888/article/7/Jeff-Vader-autographs
ERROR - 2012-10-30 11:18:43 --> 404 Page Not Found --> http://cms:8888/article/5/Vader-I-can-kill-you-with-a-single-tought
